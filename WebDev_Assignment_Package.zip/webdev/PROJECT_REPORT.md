# SPC 2201: WebDev01 — Assignment Process Documentation

**Project:** WebDev Member Registration  
**Student:** Moses Muriki Muthuri  
**Registration Number:** CT100/G  
**Unit:** SPC 2201: WebDev01  
**Repository:** https://github.com/omondi-alex/webdev

## 1. Introduction

This project is a responsive member-registration website built with HTML, CSS, and JavaScript. It provides a registration form, validates user input, displays registered members, counts members, allows a member to be removed, and includes a Dark Mode toggle.

## 2. Objectives

- Select the required DOM elements with `document.getElementById()` and `querySelector()` / `querySelectorAll()`.
- Capture and validate form submissions.
- Display field-specific validation messages and clear them after correction.
- Create member entries dynamically.
- Keep the member counter accurate.
- Display success feedback and reset the form after a valid registration.
- Remove a member from the list.
- Toggle between light and dark themes.

## 3. Tools and Technologies

- HTML5 — page structure and form controls.
- CSS3 — layout, responsive design, form states, and themes.
- JavaScript — DOM selection, event listeners, validation, and dynamic member-list updates.
- GitHub — source-code version control and submission repository.
- A modern browser — running and testing the application.

## 4. Project Files

- `index.html`: form structure, member list, counter, and theme button.
- `style.css`: page layout, responsive styles, validation states, and dark theme.
- `script.js`: DOM selection, validation, submission handling, member creation/removal, counter updates, and Dark Mode.
- `PROJECT_REPORT.md`: this process documentation.

## 5. Implementation Process

1. Inspected the HTML and identified the form, nine controls, error-message spans, success-message area, member list, member counter, and theme button.
2. Confirmed that the HTML links to `style.css` and loads `script.js`.
3. Added JavaScript selectors and console assertions to check that expected form controls and error spans exist.
4. Added field validation for required values, email format, password length, matching passwords, past date of birth, phone-number format, and minimum name/bio lengths.
5. Added `input` and `change` event listeners to clear errors when fields are corrected.
6. Captured the form `submit` event and prevented the browser from reloading the page.
7. Added valid members to an in-memory array and created member-list elements with DOM methods and `textContent`.
8. Updated the counter and empty-list message whenever members are added or removed.
9. Added a Remove button for each member and prevented duplicate email registrations within the current page session.
10. Displayed a success message, reset the form, and cleared validation errors after a successful registration.
11. Added a Dark Mode button that toggles the `dark` class on the page body and updates the button label.
12. Prepared a manual test checklist to verify the features in a browser.

## 6. Test Plan and Results to Record

The following tests should be performed in a browser before submission. Record the actual outcome after testing; do not mark a test as passed without running it.

| Test | Procedure | Expected result |
|---|---|---|
| Empty form | Click Register without filling fields | Required-field messages appear |
| Invalid email | Enter an invalid email | Email error is displayed |
| Short password | Enter fewer than 8 characters | Password error is displayed |
| Password mismatch | Enter different passwords | Confirmation error is displayed |
| Correct a field | Fix a field with an error | Its error clears when valid |
| Successful registration | Complete every field correctly and submit | Member appears; count increases; success message appears; form resets |
| Duplicate email | Register the same email twice | Duplicate email is rejected |
| Remove member | Click Remove on a listed member | Member disappears and count decreases |
| Empty list | Remove the final member | Empty-state message returns |
| Dark Mode | Click Dark Mode, then Light Mode | Theme switches in both directions |
| Mobile layout | Open the page on a phone-width screen | Cards and form fields stack for easy use |
| Console checks | Open browser developer console | No JavaScript errors; expected controls/error spans are found |

**Actual test date:** ____________________  
**Tested by:** ____________________  
**Notes / defects fixed:** ______________________________________________

## 7. Limitations

- Members are held in JavaScript memory only. Refreshing the page clears the member list; there is no server or database.
- Passwords are validated in the browser but are not stored or sent to a server.
- Client-side validation is for demonstration and should not replace server-side validation in a production application.

## 8. Conclusion

The project demonstrates core Web Development skills: DOM selection, form events, client-side validation, dynamic HTML element creation, list management, counter updates, user feedback, responsive styling, and theme switching. Run the test plan above and update the test record with the actual results before submitting.

## 9. Submission Checklist

- [ ] Confirm `index.html`, `style.css`, and `script.js` are present in the repository root.
- [ ] Open the page in a browser and complete the test plan.
- [ ] Review the browser console and fix any errors.
- [ ] Commit the final code and this report to the GitHub repository.
- [ ] Copy the repository URL into the assignment Google Form.
- [ ] Select the correct assignment number and tick the originality declaration only if it is truthful.
