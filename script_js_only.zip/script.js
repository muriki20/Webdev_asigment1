// SPC 2201 WebDev01 - Member Registration
// DOM selection: required form elements, inputs, error spans, list, count and theme button.
const form = document.getElementById("regform");
const themeButton = document.getElementById("theme");
const memberList = document.getElementById("memberList");
const memberCount = document.getElementById("count");
const successMessage = document.getElementById("successMsg");
const emptyNote = document.getElementById("emptyNote");

const fields = [
  { id: "name", errorId: "nameError", label: "Full name" },
  { id: "email", errorId: "emailError", label: "Email" },
  { id: "password", errorId: "passwordError", label: "Password" },
  { id: "confirm-password", errorId: "confirmError", label: "Confirm password" },
  { id: "gender", errorId: "genderError", label: "Gender" },
  { id: "dob", errorId: "dobError", label: "Date of birth" },
  { id: "country", errorId: "countryError", label: "Country" },
  { id: "phone", errorId: "phoneError", label: "Phone number" },
  { id: "bio", errorId: "bioError", label: "Bio" }
];

// Use querySelector to confirm all expected form controls and error spans exist.
const formControls = form.querySelectorAll("input, select, textarea");
const errorSpans = form.querySelectorAll(".error");
console.assert(formControls.length === fields.length, "Check the number of form controls.");
console.assert(errorSpans.length === fields.length, "Check the number of error spans.");
console.assert(memberList.tagName.toLowerCase() === "ul", "Member list should be a UL.");

let members = [];
let nextMemberId = 1;

function getValue(id) {
  const element = document.getElementById(id);
  return element.value.trim();
}

function showError(field, message) {
  document.getElementById(field.errorId).textContent = message;
  document.getElementById(field.id).classList.add("invalid");
  document.getElementById(field.id).setAttribute("aria-invalid", "true");
}

function clearError(field) {
  document.getElementById(field.errorId).textContent = "";
  document.getElementById(field.id).classList.remove("invalid");
  document.getElementById(field.id).removeAttribute("aria-invalid");
}

function validateField(field) {
  const input = document.getElementById(field.id);
  const value = input.value.trim();
  let message = "";

  if (!value) {
    message = `${field.label} is required.`;
  } else if (field.id === "name" && value.length < 2) {
    message = "Enter a name with at least 2 characters.";
  } else if (field.id === "email" &&
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
    message = "Enter a valid email address.";
  } else if (field.id === "password" && input.value.length < 8) {
    message = "Password must be at least 8 characters.";
  } else if (field.id === "confirm-password" &&
    input.value !== document.getElementById("password").value) {
    message = "Passwords do not match.";
  } else if (field.id === "dob" &&
    input.value >= new Date().toISOString().slice(0, 10)) {
    message = "Date of birth must be in the past.";
  } else if (field.id === "phone" &&
    !/^\+?[0-9\s()-]{7,20}$/.test(value)) {
    message = "Enter a valid phone number.";
  } else if (field.id === "bio" && value.length < 5) {
    message = "Bio must contain at least 5 characters.";
  }

  if (message) {
    showError(field, message);
    return false;
  }
  clearError(field);
  return true;
}

// Requirement: clear validation errors as the user corrects each field.
fields.forEach(field => {
  const input = document.getElementById(field.id);
  input.addEventListener("input", () => {
    validateField(field);
    if (field.id === "password") {
      const confirmation = fields.find(item => item.id === "confirm-password");
      if (getValue("confirm-password")) validateField(confirmation);
    }
  });
  input.addEventListener("change", () => validateField(field));
});

function updateMemberCount() {
  memberCount.textContent = String(members.length);
  emptyNote.classList.toggle("hidden", members.length > 0);
}

function renderMembers() {
  // Keep the empty-state item; remove only previously generated member rows.
  memberList.querySelectorAll(".member-item").forEach(item => item.remove());

  members.forEach(member => {
    const item = document.createElement("li");
    item.className = "member-item";

    const info = document.createElement("div");
    info.className = "info";

    const name = document.createElement("strong");
    name.textContent = member.name;

    const email = document.createElement("span");
    email.textContent = member.email;

    const details = document.createElement("span");
    details.textContent = `${member.country} • ${member.phone}`;

    info.append(name, email, details);

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "remove";
    removeButton.textContent = "Remove";
    removeButton.setAttribute("aria-label", `Remove ${member.name}`);

    // Requirement: remove a member and refresh the displayed count.
    removeButton.addEventListener("click", () => {
      members = members.filter(savedMember => savedMember.id !== member.id);
      renderMembers();
      showSuccess(`${member.name} was removed from the member list.`);
    });

    item.append(info, removeButton);
    memberList.appendChild(item);
  });

  updateMemberCount();
}

function showSuccess(message) {
  successMessage.textContent = message;
  successMessage.classList.remove("hidden");
}

function hideSuccess() {
  successMessage.textContent = "";
  successMessage.classList.add("hidden");
}

// Requirement: capture submission, validate every field, register member, update count,
// show success feedback, then reset the form and validation state.
form.addEventListener("submit", event => {
  event.preventDefault();
  hideSuccess();

  const validationResults = fields.map(validateField);
  if (validationResults.some(isValid => !isValid)) {
    const firstInvalid = form.querySelector(".invalid");
    if (firstInvalid) firstInvalid.focus();
    return;
  }

  const email = getValue("email").toLowerCase();
  if (members.some(member => member.email.toLowerCase() === email)) {
    const emailField = fields.find(field => field.id === "email");
    showError(emailField, "This email is already registered.");
    document.getElementById("email").focus();
    return;
  }

  members.push({
    id: nextMemberId++,
    name: getValue("name"),
    email,
    country: getValue("country"),
    phone: getValue("phone")
  });

  renderMembers();
  form.reset();
  fields.forEach(clearError);
  showSuccess("Member registered successfully!");
});

// Requirement: Dark Mode toggle.
themeButton.addEventListener("click", () => {
  const isDark = document.body.classList.toggle("dark");
  themeButton.textContent = isDark ? "Light Mode" : "Dark Mode";
  themeButton.setAttribute("aria-pressed", String(isDark));
});

// Initial state.
updateMemberCount();
console.info("WebDev registration app initialized.", {
  controlsFound: formControls.length,
  errorSpansFound: errorSpans.length
});
